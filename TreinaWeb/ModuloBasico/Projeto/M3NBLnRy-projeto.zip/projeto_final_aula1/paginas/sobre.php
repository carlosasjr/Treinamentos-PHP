<div class="page-header">
    <h3>Sobre o TreinaWeb</h3>
</div>

<p>
    O TreinaWeb é o portal líder no segmento de cursos online com foco em Tecnologia da Informação, no Brasil.
</p>

<p>
    Ministramos cursos relacionados às áreas de desenvolvimento e manutenção de sites e softwares, sempre atualizados com o que há de mais novo no mercado mundial de TI. Além disso, só aqui você tem instrutores especializados à sua disposição para tirar todas as dúvidas relacionadas aos cursos.
</p>

<p>
    É um <b>prazer</b> tê-lo como <b>nosso aluno</b>! Aguardamos ansiosamente que você também estude conosco os cursos de PHP que dão continuidade ao que foi ensinado neste curso:
</p>

<p>
<ul>
    <li><a href="http://www.treinaweb.com.br/curso/php-intermediario">Curso de PHP Intermediário</a></li>
    <li><a href="http://www.treinaweb.com.br/curso/php-avancado">Curso de PHP Avançado</a></li>
</ul>
</p>

