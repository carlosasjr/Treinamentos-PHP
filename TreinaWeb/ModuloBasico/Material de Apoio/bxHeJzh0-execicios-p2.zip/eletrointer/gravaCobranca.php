<?php

require 'config.php';
require 'lib/funcs.php';

$codcliente 	= trim($_POST['codcliente']);
$nomecliente 	= trim($_POST['nomecliente']);
$qtdkwh 		= trim($_POST['qtdkwh']);
$tipocliente 	= trim($_POST['tipocliente']);

$erro = 0;

if (strlen($nomecliente) < 3) $erro++;
if (!is_numeric($codcliente)) $erro++;
if (strlen($qtdkwh) == 0 || !is_numeric($qtdkwh)) $erro++;

if ($erro) {
    header('Location: index.php?pagina=criar&erro=1');
    exit;
}

$con = conecta();

$insert = "INSERT INTO tbl_cobrancas"
        . "(codcliente, nomecliente, qtdkwh, tipocliente)"
        . "VALUES ($codcliente, '$nomecliente', $qtdkwh, '$tipocliente')";

echo $insert;

$res = mysqli_query($con, $insert);

var_dump($res);

if ($res) {
    header('Location: index.php?pagina=criar&sucesso=1');
}
        
