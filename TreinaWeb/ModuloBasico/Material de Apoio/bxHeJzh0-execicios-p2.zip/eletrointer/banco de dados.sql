-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 29-Abr-2016 às 16:07
-- Versão do servidor: 5.6.21
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `eletrointer`
--

CREATE DATABASE eletrointer;

USE eletrointer;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbl_cobrancas`
--

CREATE TABLE IF NOT EXISTS `tbl_cobrancas` (
  `codcliente` int(11) NOT NULL,
  `nomecliente` varchar(200) NOT NULL,
  `qtdkwh` int(11) NOT NULL,
  `tipocliente` char(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tbl_cobrancas`
--

INSERT INTO `tbl_cobrancas` (`codcliente`, `nomecliente`, `qtdkwh`, `tipocliente`) VALUES
(1, 'Elias', 25, 'residencial'),
(2, 'Ferro S.A', 50, 'indústrial'),
(3, 'Loja de tudo', 40, 'comercial');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_cobrancas`
--
ALTER TABLE `tbl_cobrancas`
  ADD PRIMARY KEY (`codcliente`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
