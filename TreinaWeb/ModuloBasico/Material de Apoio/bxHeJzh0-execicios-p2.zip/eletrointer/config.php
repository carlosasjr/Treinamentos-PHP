<?php

// Dados de conexão do banco
define('HOST', 'localhost');
define('USER', 'root');
define('PASS', '');
define('BANCO', 'eletrointer');
