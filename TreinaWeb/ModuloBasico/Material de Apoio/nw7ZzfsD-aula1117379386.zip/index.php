<?php

echo 'Ola mundo via CLI';