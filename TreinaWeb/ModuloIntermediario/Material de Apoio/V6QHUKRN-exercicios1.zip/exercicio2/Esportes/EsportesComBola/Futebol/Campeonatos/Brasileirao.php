<?php

namespace Esportes\EsportesComBola\Futebol\Campeonatos;

class Brasileirao
{
	function __construct()
	{
		echo 'Instanciei Brasileirao <br>';
	}
}