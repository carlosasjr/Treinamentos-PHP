<?php

echo "
    <article>
        <header> <h1>{$category_title}</h1> </header>
        <p>{$category_content}</p>
    </article> <hr>
";
