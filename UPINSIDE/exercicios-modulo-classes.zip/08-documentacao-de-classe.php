<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <title>WS PHP - Documentação de Classe</title>
    </head>
    <body>
        <?php
        require('./inc/Config.inc.php');
        $documentar = new DocumentacaoDeClasse('UPINSIDE');
        //$documentar->
        ?>
    </body>
</html>
