<?php

class MinhaSegundaClasse extends MinhaClasse {

    public $Idade;
    
    function getIdade() {
        return $this->Idade;
    }

    function setIdade($Idade) {
        $this->Idade = $Idade;
    }



}
