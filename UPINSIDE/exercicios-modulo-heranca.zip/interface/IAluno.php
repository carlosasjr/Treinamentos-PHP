<?php

interface IAluno {
    
    public function Matricular($Curso);
    
    public function Formar();
    
}
