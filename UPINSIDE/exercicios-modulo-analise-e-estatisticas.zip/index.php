<?php
require('./_app/Config.inc.php');
$sessao = new Session;

var_dump($sessao);
echo "<hr>";
var_dump($_SESSION);
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="mit" content="2018-05-21T08:44:32-03:00+29610">
        <title>WS PHP - Análise de Estatísticas</title>
    </head>
    <body>
        <?php
        // put your code here
        ?>
    </body>
</html>
